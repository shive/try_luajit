"""Suite Required Suite: Every application supports open, print, run, and quit
Level 1, version 1

Generated from /Volumes/Sap/System Folder/Extensions/AppleScript
AETE/AEUT resource version 1/0, language 0, script 0
"""

import aetools
import MacOS

_code = 'reqd'

from _builtinSuites.builtin_Suite import *
class Required_Suite_Events(builtin_Suite_Events):

    pass


#
# Indices of types declared in this module
#
_classdeclarations = {
}

_propdeclarations = {
}

_compdeclarations = {
}

_enumdeclarations = {
}
