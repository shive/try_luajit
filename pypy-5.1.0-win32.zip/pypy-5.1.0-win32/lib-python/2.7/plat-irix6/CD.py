from warnings import warnpy3k
warnpy3k("the CD module has been removed in Python 3.0", stacklevel=2)
del warnpy3k

ERROR           = 0
NODISC          = 1
READY           = 2
PLAYING         = 3
PAUSED          = 4
STILL           = 5

AUDIO           = 0
PNUM            = 1
INDEX           = 2
PTIME           = 3
ATIME           = 4
CATALOG         = 5
IDENT           = 6
CONTROL         = 7

CDDA_DATASIZE   = 2352

##CDDA_SUBCODESIZE      = (sizeof(struct subcodeQ))
##CDDA_BLOCKSIZE        = (sizeof(struct cdframe))
##CDDA_NUMSAMPLES       = (CDDA_DATASIZE/2)
##
##CDQ_PREEMP_MASK       = 0xd
##CDQ_COPY_MASK = 0xb
##CDQ_DDATA_MASK        = 0xd
##CDQ_BROADCAST_MASK    = 0x8
##CDQ_PREEMPHASIS       = 0x1
##CDQ_COPY_PERMITTED    = 0x2
##CDQ_DIGITAL_DATA      = 0x4
##CDQ_BROADCAST_USE     = 0x8
##
##CDQ_MODE1     = 0x1
##CDQ_MODE2     = 0x2
##CDQ_MODE3     = 0x3
